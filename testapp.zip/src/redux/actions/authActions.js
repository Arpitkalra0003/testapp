import {REDUX_CONSTANTS} from '../constants';
import {authSignIn} from '../../services/auth';

const types = REDUX_CONSTANTS;

export function signIn(credentails){
    return async (dispatch) => {
        dispatch({type:types.AUTH_SIGN_IN_REQUEST});
        return authSignIn(credentails)
        .then((response)=>{
            dispatch({
                type:types.AUTH_SIGN_IN_SUCCESS,
                id:response.id,
                email:response.email,
                name:response.name
            })

        })
      

    }

}
