import axios from 'axios';


export function authSignIn(credentails){
    return new Promise((resolve,reject) => {
        axios
        .post("http://14.99.254.106:5000/api/authenticate",credentails)
        .then((response)=>{
            if(response.status === 200)
            {
                resolve(response.data)
            }
            reject(response.data)
        })
    } )

}