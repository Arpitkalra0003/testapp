import {REDUX_CONSTANTS} from '../constants';

const types = REDUX_CONSTANTS

export default function reducer(state = {},actions){
    switch (actions.type) {
        case types.AUTH_SIGN_IN_SUCCESS:
            return{
                ...state,
                user:{
                    id:actions.id,
                    email:actions.email,
                    name:actions.name
                }
            }
        default:
            return state;
    }

}