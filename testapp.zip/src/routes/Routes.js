import React, {Suspense} from 'react'
import {
Route,
Switch,
BrowserRouter,
useLocation
} from 'react-router-dom';

import Login from '../containers/Login/index';
import ProjectListing from '../containers/ProjectListing/index';


const Routes = () => (
    <BrowserRouter>
        <Switch>    
     <Route exact path='/'  component={Login} />
     <Route exact path='/projects'  component={ProjectListing} />
        </Switch>
    </BrowserRouter>
)
export default Routes;