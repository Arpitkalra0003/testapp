import React, {useState,useEffect} from 'react'
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';
import Banner from '../../Login-Banner.jpg';
import logo from '../../logo.png';
import '../../App.css';
import TextField from '@material-ui/core/TextField';
import {Formik,ErrorMessage} from 'formik';
import {withRouter} from 'react-router-dom';
import Button from '@material-ui/core/Button';
import {signIn} from '../../redux/actions/authActions'
import {useDispatch} from 'react-redux';
import {useHistory} from 'react-router-dom'

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    //   background:'#f8f8f8',
      backgroundImage:'url('+Banner+')' ,
      backgroundRepeat:'no-repeat',
      backgroundSize: 'cover',
      backgroundPosition:'100%',
      height:'100vh'
    },
    paper: {
      height: 140,
      width: 100,
    },
    control: {
      padding: theme.spacing(2),
    },
  }));

function Login() {
    const dispatch = useDispatch()
    const history = useHistory();
    const classes = useStyles();
    const [username,setUsername] = useState('testuser1@qassure.com')
    const [password,setPassword] = useState('user1@qach')

    const onSubmit = async () => {

    await dispatch(signIn( {
        'Username':username,
        'Password':password
    }))
    history.push('/projects')
       

      

    }
    const onUsername = (event)=>{
    setUsername(event.target.value)
    }

    const onPassword = (event)=>{
        setPassword(event.target.value)
            }

  return (
    <Grid container className={classes.root} >
    <Grid item xs={8}>

    </Grid>
    <Grid item xs={4} >
        <div className={'loginDiv'}>
        <h1 className={'loginHead'}>Login...</h1>

 
      <TextField label="Username" className={'inputbox'} onChange={onUsername}  />
      <TextField  label="Password" className={'inputbox'} onChange={onPassword} />
  
      <Button variant="contained" color="primary" className={'loginBtn'} onClick={onSubmit}>
  Log in now
</Button>
<div>
<img src={logo} className={'logo'}  />
</div>

        </div>

</Grid>
  
    </Grid>
   
  );
}

export default Login;
